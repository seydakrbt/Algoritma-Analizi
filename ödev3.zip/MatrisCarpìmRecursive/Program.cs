﻿using System;

class MatrisCarpimi
{
    static void Main()
    {
        int boyut;

        Console.Write("Matris boyutunu giriniz: ");
        while (!int.TryParse(Console.ReadLine(), out boyut) || boyut <= 0)
        {
            Console.WriteLine("Geçersiz giriş. Pozitif bir tam sayı giriniz.");
            Console.Write("Matris boyutunu giriniz: ");
        }

        int[,] matris1 = new int[boyut, boyut];
        Console.WriteLine("İlk matrisin elemanlarını giriniz:");
        MatrisiDoldur(matris1);

        int[,] matris2 = new int[boyut, boyut];
        Console.WriteLine("İkinci matrisin elemanlarını giriniz:");
        MatrisiDoldur(matris2);

        int[,] sonuc = MatrisCarpimiYap(matris1, matris2);

        Console.WriteLine("Matris Çarpımı:");
        MatrisiYazdir(sonuc);
    }
    static void MatrisiDoldur(int[,] matris)
    {
        int boyut = matris.GetLength(0);
        for (int i = 0; i < boyut; i++)
        {
            for (int j = 0; j < boyut; j++)
            {
                Console.Write($"[{i},{j}]: ");
                while (!int.TryParse(Console.ReadLine(), out matris[i, j]))
                {
                    Console.WriteLine("Geçersiz giriş. Bir tam sayı giriniz.");
                    Console.Write($"[{i},{j}]: ");
                }
            }
        }
    }

    static int[,] MatrisCarpimiYap(int[,] matris1, int[,] matris2)
    {
        int boyut = matris1.GetLength(0);
        int[,] sonuc = new int[boyut, boyut];

        MatrisCarpimiYardimci(matris1, matris2, sonuc, boyut, 0, 0, 0);

        return sonuc;
    }

    // Yardımcı özyineli fonksiyon
    static void MatrisCarpimiYardimci(int[,] matris1, int[,] matris2, int[,] sonuc, int boyut, int satir, int sutun, int k)
    {
        if (satir >= boyut) return;    //n

        if (sutun < boyut)             //n
        {
            if (k < boyut)             //n
            {
                sonuc[satir, sutun] += matris1[satir, k] * matris2[k, sutun];
                MatrisCarpimiYardimci(matris1, matris2, sonuc, boyut, satir, sutun, k + 1);
            }
            MatrisCarpimiYardimci(matris1, matris2, sonuc, boyut, satir, sutun + 1, 0);
        }
        else
        {
            MatrisCarpimiYardimci(matris1, matris2, sonuc, boyut, satir + 1, 0, 0);
        }
    }
    static void MatrisiYazdir(int[,] matris)
    {
        int boyut = matris.GetLength(0);
        for (int i = 0; i < boyut; i++)
        {
            for (int j = 0; j < boyut; j++)
            {
                Console.Write(matris[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}
