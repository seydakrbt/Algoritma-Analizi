﻿using System;

class MatrixMultiplication
{
    static void Main()
    {
        int n;

        Console.Write("Matris boyutunu giriniz: ");
        while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
        {
            Console.WriteLine("Geçersiz giriş. Pozitif bir tam sayı giriniz.");
            Console.Write("Matris boyutunu giriniz: ");
        }
        int[,] matrix1 = new int[n, n];
        Console.WriteLine("İlk matrisin elemanlarını giriniz:");
        MatrisDoldur(matrix1);

        int[,] matrix2 = new int[n, n];
        Console.WriteLine("İkinci matrisin elemanlarını giriniz:");
        MatrisDoldur(matrix2);

        int[,] result = MatrisCarpma(matrix1, matrix2);

        Console.WriteLine("Matris Çarpımı:");
        MatrisYazdir(result);
    }
    static void MatrisDoldur(int[,] matrix)
    {
        int n = matrix.GetLength(0);
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write($"[{i},{j}]: ");
                while (!int.TryParse(Console.ReadLine(), out matrix[i, j]))
                {
                    Console.WriteLine("Geçersiz giriş. Bir tam sayı giriniz.");
                    Console.Write($"[{i},{j}]: ");
                }
            }
        }
    }
    static int[,] MatrisCarpma(int[,] matrix1, int[,] matrix2)
    {
        int n = matrix1.GetLength(0);
        int[,] result = new int[n, n];

        for (int i = 0; i < n; i++)             //n
        {
            for (int j = 0; j < n; j++)         //n
            {
                result[i, j] = 0;
                for (int k = 0; k < n; k++)     //n
                {
                    result[i, j] += matrix1[i, k] * matrix2[k, j];
                }
            }
        }

        return result;
    }
    static void MatrisYazdir(int[,] matrix)
    {
        int n = matrix.GetLength(0);
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write(matrix[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}
