﻿using System;

class GezginSaticiIteratif
{
    static int[] GezginSatici(int[,] graf)
    {
        int sehirSayisi = graf.GetLength(0);
        int[] minYol = new int[sehirSayisi + 1];
        int[] sehirler = new int[sehirSayisi];
        for (int i = 0; i < sehirSayisi; i++)
        {
            sehirler[i] = i;
        }

        int minMaliyet = int.MaxValue;
        do
        {
            int gecerliMaliyet = 0;
            for (int i = 0; i < sehirSayisi - 1; i++)
            {
                int baslangic = sehirler[i];
                int bitis = sehirler[i + 1];
                if (graf[baslangic, bitis] == 0)
                {
                    gecerliMaliyet = int.MaxValue;
                    break;
                }
                gecerliMaliyet += graf[baslangic, bitis];
            }
            if (gecerliMaliyet < minMaliyet)
            {
                minMaliyet = gecerliMaliyet;
                sehirler.CopyTo(minYol, 0);
            }
        } while (SonrakiPermutasyon(sehirler));

        minYol[sehirSayisi] = minYol[0];
        return minYol;
    }

    static bool SonrakiPermutasyon(int[] dizi)
    {
        int i = dizi.Length - 2;
        while (i >= 0 && dizi[i] >= dizi[i + 1])
        {
            i--;
        }
        if (i < 0)
        {
            return false;
        }
        int j = dizi.Length - 1;
        while (dizi[j] <= dizi[i])
        {
            j--;
        }
        int gecici = dizi[i];
        dizi[i] = dizi[j];
        dizi[j] = gecici;
        Array.Reverse(dizi, i + 1, dizi.Length - i - 1);
        return true;
    }

    static void Main()
    {
        int[,] graf = {
            {0, 10, 15, 20},
            {10, 0, 35, 25},
            {15, 35, 0, 30},
            {20, 25, 30, 0}
        };

        int[] minYol = GezginSatici(graf);
        Console.WriteLine("Minimum Yol: " + string.Join(" -> ", minYol));
    }
}
