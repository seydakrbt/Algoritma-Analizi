﻿using System;

class GezginSaticiRecursive
{
    static int[] GezginSatici(int[,] graf)
    {
        int sehirSayisi = graf.GetLength(0);
        int[] minYol = new int[sehirSayisi + 1];
        int[] sehirler = new int[sehirSayisi];
        for (int i = 0; i < sehirSayisi; i++)
        {
            sehirler[i] = i;
        }

        int minMaliyet = int.MaxValue;
        Permutasyon(sehirler, 0, sehirSayisi - 1, ref minYol, ref minMaliyet, graf);

        minYol[sehirSayisi] = minYol[0];
        return minYol;
    }

    static void Permutasyon(int[] sehirler, int sol, int sag, ref int[] minYol, ref int minMaliyet, int[,] graf)
    {
        if (sol == sag)
        {
            int gecerliMaliyet = 0;
            for (int i = 0; i < sehirler.Length - 1; i++)
            {
                int baslangic = sehirler[i];
                int bitis = sehirler[i + 1];
                if (graf[baslangic, bitis] == 0)
                {
                    gecerliMaliyet = int.MaxValue;
                    break;
                }
                gecerliMaliyet += graf[baslangic, bitis];
            }
            if (gecerliMaliyet < minMaliyet)
            {
                minMaliyet = gecerliMaliyet;
                sehirler.CopyTo(minYol, 0);
            }
        }
        else
        {
            for (int i = sol; i <= sag; i++)
            {
                Swap(ref sehirler[sol], ref sehirler[i]);
                Permutasyon(sehirler, sol + 1, sag, ref minYol, ref minMaliyet, graf);
                Swap(ref sehirler[sol], ref sehirler[i]);
            }
        }
    }

    static void Swap(ref int a, ref int b)
    {
        int gecici = a;
        a = b;
        b = gecici;
    }

    static void Main()
    {
        int[,] graf = {
            {0, 10, 15, 20},
            {10, 0, 35, 25},
            {15, 35, 0, 30},
            {20, 25, 30, 0}
        };

        int[] minYol = GezginSatici(graf);
        Console.WriteLine("Minimum Yol: " + string.Join(" -> ", minYol));
    }
}
