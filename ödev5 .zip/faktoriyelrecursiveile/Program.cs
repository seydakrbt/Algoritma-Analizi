﻿using System;

namespace faktoriyelrecursiveile
{
    class faktoriyel
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bir sayi giriniz= ");
            int n = Convert.ToInt32(Console.ReadLine());
            int result = Factoriyel(n);
            Console.WriteLine($"Faktoriyel({n}) = {result}");
            //Console.WriteLine("Faktöriyel: " + n + " = " + result);
            
        }
        static int Factoriyel(int n)
        {
            if (n == 0)
            {
                return 1;
            }
            else
            {
                return n * Factoriyel(n - 1);
            }
        }
    }
}
