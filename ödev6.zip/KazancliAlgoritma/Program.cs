﻿using System;

class Program
{
    static void Main()
    {
        int sayi1 = 2135;
        int sayi2 = 4014;

        int sonuc = Carpma(sayi1, sayi2);

        Console.WriteLine("A * B = " + sonuc);
    }

    static int Carpma(int num1, int num2)
    {
        int[] sonucDizisi = new int[(int)Math.Floor(Math.Log10(num1)) + (int)Math.Floor(Math.Log10(num2)) + 2];

        int elde = 0;
        int pozisyon;

        for (int i = 0; i < num1.ToString().Length; i++)
        {
            pozisyon = i;
            for (int j = 0; j < num2.ToString().Length; j++)
            {
                int carpim = (num1 % 10) * (num2 % 10) + elde + sonucDizisi[pozisyon];
                elde = carpim / 10;
                sonucDizisi[pozisyon] = carpim % 10;
                pozisyon++;
                num2 /= 10;
            }
            if (elde > 0)
            {
                sonucDizisi[pozisyon] = elde;
                elde = 0;
            }
            num1 /= 10;
        }

        int sonuc = 0;
        for (int i = sonucDizisi.Length - 1; i >= 0; i--)
        {
            sonuc = sonuc * 10 + sonucDizisi[i];
        }

        return sonuc;
    }
}
