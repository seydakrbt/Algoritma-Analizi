﻿using System;

class Dijkstra
{
    public static void DijkstraAlgoritmasi(int[,] grafik, int kaynak)
    {
        int dugumSayisi = grafik.GetLength(0);
        int[] mesafe = new int[dugumSayisi]; // Mesafeleri tutar
        bool[] kisaYolAgaci = new bool[dugumSayisi]; // Ziyaret edilen düğümleri takip eder

        // Başlangıç olarak tüm mesafeleri sonsuz ve tüm düğümleri ziyaret edilmemiş olarak ayarla
        for (int i = 0; i < dugumSayisi; ++i)
        {
            mesafe[i] = int.MaxValue;
            kisaYolAgaci[i] = false;
        }

        mesafe[kaynak] = 0; // Kaynak düğümün mesafesi 0

        for (int sayac = 0; sayac < dugumSayisi - 1; ++sayac)
        {
            int u = EnKisaMesafe(mesafe, kisaYolAgaci, dugumSayisi); // Minimum mesafeli düğümü seç
            kisaYolAgaci[u] = true; // Seçilen düğümü ziyaret edildi olarak işaretle

            // Seçilen düğümün komşularını güncelle
            for (int v = 0; v < dugumSayisi; ++v)
                if (!kisaYolAgaci[v] && Convert.ToBoolean(grafik[u, v]) && mesafe[u] != int.MaxValue && mesafe[u] + grafik[u, v] < mesafe[v])
                    mesafe[v] = mesafe[u] + grafik[u, v];
        }

        Yazdir(mesafe, dugumSayisi); // Sonuçları yazdır
    }

    private static int EnKisaMesafe(int[] mesafe, bool[] kisaYolAgaci, int dugumSayisi)
    {
        int min = int.MaxValue;
        int minIndeks = 0;

        // Ziyaret edilmemiş düğümler arasında minimum mesafeyi bul
        for (int v = 0; v < dugumSayisi; ++v)
        {
            if (kisaYolAgaci[v] == false && mesafe[v] <= min)
            {
                min = mesafe[v];
                minIndeks = v;
            }
        }
        return minIndeks;
    }

    private static void Yazdir(int[] mesafe, int dugumSayisi)
    {
        Console.WriteLine("Düğüm   Kaynaktan Mesafe");

        for (int i = 0; i < dugumSayisi; ++i)
            Console.WriteLine("{0}\t  {1}", i, mesafe[i]);
    }
}

class Program
{
    static void Main()
    {
        int[,] grafik =  {
                        { 0, 2, 0, 1, 0 },
                        { 2, 0, 3, 2, 0 },
                        { 0, 3, 0, 4, 6 },
                        { 1, 2, 4, 0, 5 },
                        { 0, 0, 6, 5, 0 }
                       };

        Dijkstra.DijkstraAlgoritmasi(grafik, 0); // Algoritmayı çalıştır ve sonuçları yazdır
    }
}
