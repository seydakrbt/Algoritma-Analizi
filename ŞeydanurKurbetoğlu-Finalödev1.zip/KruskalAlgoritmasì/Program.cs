﻿using System;

class Kruskal
{
    class Kenar : IComparable<Kenar>
    {
        public int Kaynak, Hedef, Agirlik;

        // Ağırlığa göre kenarları karşılaştır
        public int CompareTo(Kenar karsilastirmaKenar)
        {
            return this.Agirlik - karsilastirmaKenar.Agirlik;
        }
    }

    class Kume
    {
        public int Ana, Rütbe;
    }

    int dugumSayisi, kenarSayisi;
    Kenar[] kenarlar;

    Kruskal(int d, int k)
    {
        dugumSayisi = d;
        kenarSayisi = k;
        kenarlar = new Kenar[kenarSayisi];
        for (int i = 0; i < k; ++i)
            kenarlar[i] = new Kenar();
    }

    int Bul(Kume[] kumeler, int i)
    {
        if (kumeler[i].Ana != i)
            kumeler[i].Ana = Bul(kumeler, kumeler[i].Ana);

        return kumeler[i].Ana;
    }

    void Birlesim(Kume[] kumeler, int x, int y)
    {
        int xKök = Bul(kumeler, x);
        int yKök = Bul(kumeler, y);

        // Rütbelere göre ağaçları birleştir
        if (kumeler[xKök].Rütbe < kumeler[yKök].Rütbe)
            kumeler[xKök].Ana = yKök;
        else if (kumeler[xKök].Rütbe > kumeler[yKök].Rütbe)
            kumeler[yKök].Ana = xKök;
        else
        {
            kumeler[yKök].Ana = xKök;
            ++kumeler[xKök].Rütbe;
        }
    }

    void KruskalAlgoritmasi()
    {
        Kenar[] sonuc = new Kenar[dugumSayisi];
        int e = 0;
        int i = 0;
        for (i = 0; i < dugumSayisi; ++i)
            sonuc[i] = new Kenar();

        Array.Sort(kenarlar); // Kenarları ağırlıklarına göre sırala

        Kume[] kumeler = new Kume[dugumSayisi];
        for (i = 0; i < dugumSayisi; ++i)
            kumeler[i] = new Kume();

        for (int v = 0; v < dugumSayisi; ++v)
        {
            kumeler[v].Ana = v;
            kumeler[v].Rütbe = 0;
        }

        i = 0;

        while (e < dugumSayisi - 1)
        {
            Kenar sonrakiKenar = kenarlar[i++];
            int x = Bul(kumeler, sonrakiKenar.Kaynak);
            int y = Bul(kumeler, sonrakiKenar.Hedef);

            if (x != y)
            {
                sonuc[e++] = sonrakiKenar;
                Birlesim(kumeler, x, y);
            }
        }

        Console.WriteLine("Minimum Örtücü Ağaçta Bulunan Kenarlar:");
        for (i = 0; i < e; ++i)
            Console.WriteLine("{0} -- {1} == {2}", sonuc[i].Kaynak, sonuc[i].Hedef, sonuc[i].Agirlik);
    }

    public static void Main()
    {
        int dugumSayisi = 4;
        int kenarSayisi = 5;
        Kruskal grafik = new Kruskal(dugumSayisi, kenarSayisi);

        // Kenarları ve ağırlıklarını ekle
        grafik.kenarlar[0].Kaynak = 0;
        grafik.kenarlar[0].Hedef = 1;
        grafik.kenarlar[0].Agirlik = 10;

        grafik.kenarlar[1].Kaynak = 0;
        grafik.kenarlar[1].Hedef = 2;
        grafik.kenarlar[1].Agirlik = 6;

        grafik.kenarlar[2].Kaynak = 0;
        grafik.kenarlar[2].Hedef = 3;
        grafik.kenarlar[2].Agirlik = 5;

        grafik.kenarlar[3].Kaynak = 1;
        grafik.kenarlar[3].Hedef = 3;
        grafik.kenarlar[3].Agirlik = 15;

        grafik.kenarlar[4].Kaynak = 2;
        grafik.kenarlar[4].Hedef = 3;
        grafik.kenarlar[4].Agirlik = 4;

        grafik.KruskalAlgoritmasi(); // Algoritmayı çalıştır ve sonuçları yazdır
    }
}
