﻿using System;

class Prim
{
    private static int EnKucukAnahtar(int[] anahtar, bool[] mstKumesi, int dugumSayisi)
    {
        int min = int.MaxValue, minIndeks = -1;

        // Ziyaret edilmemiş düğümler arasında minimum anahtar değerini bul
        for (int v = 0; v < dugumSayisi; ++v)
        {
            if (mstKumesi[v] == false && anahtar[v] < min)
            {
                min = anahtar[v];
                minIndeks = v;
            }
        }
        return minIndeks;
    }

    private static void Yazdir(int[] ebeveyn, int[,] grafik, int dugumSayisi)
    {
        Console.WriteLine("Kenar \tAğırlık");
        for (int i = 1; i < dugumSayisi; ++i)
            Console.WriteLine("{0} - {1} \t{2}", ebeveyn[i], i, grafik[i, ebeveyn[i]]);
    }

    public static void PrimAlgoritmasi(int[,] grafik, int dugumSayisi)
    {
        int[] ebeveyn = new int[dugumSayisi]; // MST'de bulunan düğümleri tutar
        int[] anahtar = new int[dugumSayisi]; // Anahtar değerlerini tutar
        bool[] mstKumesi = new bool[dugumSayisi]; // MST'de bulunan düğümleri takip eder

        for (int i = 0; i < dugumSayisi; ++i)
        {
            anahtar[i] = int.MaxValue; // Anahtar değerlerini sonsuz yap
            mstKumesi[i] = false; // Tüm düğümleri ziyaret edilmemiş olarak işaretle
        }

        anahtar[0] = 0; // İlk düğümü seçmek için anahtar değerini 0 yap
        ebeveyn[0] = -1; // İlk düğümün ebeveyni yok

        for (int sayac = 0; sayac < dugumSayisi - 1; ++sayac)
        {
            int u = EnKucukAnahtar(anahtar, mstKumesi, dugumSayisi); // Minimum anahtar değerine sahip düğümü seç
            mstKumesi[u] = true; // Seçilen düğümü MST'ye ekle

            // Seçilen düğümün komşularını güncelle
            for (int v = 0; v < dugumSayisi; ++v)
            {
                if (grafik[u, v] != 0 && mstKumesi[v] == false && grafik[u, v] < anahtar[v])
                {
                    ebeveyn[v] = u;
                    anahtar[v] = grafik[u, v];
                }
            }
        }

        Yazdir(ebeveyn, grafik, dugumSayisi); // Sonuçları yazdır
    }

    public static void Main()
    {
        int[,] grafik =  {
                        { 0, 2, 0, 6, 0 },
                        { 2, 0, 3, 8, 5 },
                        { 0, 3, 0, 0, 7 },
                        { 6, 8, 0, 0, 9 },
                        { 0, 5, 7, 9, 0 }
                       };

        PrimAlgoritmasi(grafik, 5); // Algoritmayı çalıştır ve sonuçları yazdır
    }
}

